from tkinter import*
import socket
from tkinter import font
from tkinter import messagebox
import tkinter.scrolledtext as scrollText
import tkinter.ttk as exTk
from App_Client.Login_SignUp.login import Login
from App_Client.Login_SignUp.signUp import RegisterPage
from App_Client.Login_SignUp.logOut import LogOut
from App_Client.backEnd import BackEnd
import json

def btn_clicked():
    print('clicked')

class AboutUsPage(Frame):
    def __init__(self,window,master,frontEnd,backEnd):
        Frame.__init__(self,master)
        self.canvas = Canvas(
            window,
            bg = "#FFFFFF",
            height = 780,
            width = 1500,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge")
        self.canvas.place(x = 0, y = 0)


        # Background
        self.background_img = PhotoImage(file = f"./image/bg_about_us.png")
        self.background = self.canvas.create_image(
            625.0, 325.0,
            image=self.background_img)

        # Button
        self.button_back_img = PhotoImage(file = f"./image/abus_button_back.png")
        self.button_back = Button(
            activebackground = "#F49617",
            bg = "#F49617",
            image = self.button_back_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = lambda: frontEnd.navigate(frontEnd.frames['EntryPage']),
            relief = "flat")

        self.button_back.place(
            x = 591, y = 563,
            width = 71,
            height = 71)

class EntryPage(Frame):
    def __init__(self,window,master,frontEnd,backEnd):
        Frame.__init__(self,master)
        self.canvas = Canvas(
            window,
            bg = "#FFFFFF",
            height = 780,
            width = 1500,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge")
        self.canvas.place(x = 0, y = 0)


        # Background
        self.background_img = PhotoImage(file = f"./image/bg_login_signup.png")
        self.background = self.canvas.create_image(
            625.0, 325.0,
            image=self.background_img)


        # Button About Us
        self.button_abus_img = PhotoImage(file = f"./image/logsign_button_abus.png")
        self.button_abus = Button(
            activebackground = "#D8482E",
            bg = "#D8482E",
            image = self.button_abus_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = lambda: frontEnd.navigate(AboutUsPage),
            relief = "flat")

        self.button_abus.place(
            x = 460, y = 483,
            width = 360,
            height = 65)


        # Button Sign Up
        self.button_signup_img = PhotoImage(file = f"./image/logsign_button_signup.png")
        self.button_signup = Button(
            activebackground = "#D6452C",
            bg = "#D6452C",
            image = self.button_signup_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = lambda: frontEnd.navigate(RegisterPage),
            relief = "flat")

        self.button_signup.place(
            x = 460, y = 408,
            width = 360,
            height = 65)


        # Button Log In
        self.button_login_img = PhotoImage(file = f"./image/logsign_button_login.png")
        self.button_login = Button(
            activebackground = "#D03D29",
            bg = "#D03D29",
            image = self.button_login_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = lambda: frontEnd.navigate(Login),
            relief = "flat")

        self.button_login.place(
            x = 460, y = 333,
            width = 360,
            height = 65)

class HomePage(Frame):
    def __init__(self,window,master,frontEnd,backEnd):
        Frame.__init__(self,master)
        self.canvas = Canvas(
            window,
            bg = "#FFFFFF",
            height = 780,
            width = 1500,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge")
        self.canvas.place(x = 0, y = 0)


        # Background
        self.background_img = PhotoImage(file = f"./image/bg_menu.png")
        self.background = self.canvas.create_image(
            625.0, 325.0,
            image=self.background_img)


        # Button: Translator
        self.button_translator_img = PhotoImage(file = f"./image/menu_button_translator.png")
        self.button_translator = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_translator_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = btn_clicked,
            relief = "flat")

        self.button_translator.place(
            x = 177, y = 263,
            width = 425,
            height = 80)


        # Button: Topic Vocab
        self.button_topicvocab_img = PhotoImage(file = f"./image/menu_button_topicvocab.png")
        self.button_topicvocab = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_topicvocab_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = btn_clicked,
            relief = "flat")

        self.button_topicvocab.place(
            x = 657, y = 263,
            width = 425,
            height = 80)


        # Button: TOEIC LT
        self.button_lt_img = PhotoImage(file = f"./image/menu_button_lt.png")
        self.button_lt = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_lt_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = btn_clicked,
            relief = "flat")

        self.button_lt.place(
           x = 177, y = 345,
            width = 425,
            height = 80)


        # Button: TOEIC RT
        self.button_rt_img = PhotoImage(file = f"./image/menu_button_rt.png")
        self.button_rt = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_rt_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = btn_clicked,
            relief = "flat")

        self.button_rt.place(
            x = 657, y = 345,
            width = 425,
            height = 80)


        # Button: Short Story
        self.button_shortstory_img = PhotoImage(file = f"./image/menu_button_shortstory.png")
        self.button_shortstory = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_shortstory_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = btn_clicked,
            relief = "flat")

        self.button_shortstory.place(
            x = 177, y = 427,
            width = 425,
            height = 80)


        # Button: Flashcard
        self.button_flashcard_img = PhotoImage(file = f"./image/menu_button_flashcard.png")
        self.button_flashcard = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_flashcard_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = btn_clicked,
            relief = "flat")

        self.button_flashcard.place(
            x = 657, y = 427,
            width = 425,
            height = 80)


        # Button: About Us
        self.button_abus_img = PhotoImage(file = f"./image/menu_button_abus.png")
        self.button_abus = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_abus_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = btn_clicked,
            relief = "flat")

        self.button_abus.place(
            x = 177, y = 509,
            width = 425,
            height = 80)


        # Button: LOG OUT
        self.button_logout_img = PhotoImage(file = f"./image/menu_button_logout.png")
        self.button_logout = Button(
            activebackground = "#C22820",
            bg = "#C22820",
            image = self.button_logout_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = lambda: frontEnd.navigate(frontEnd.frames['EntryPage']),
            relief = "flat")

        self.button_logout.place(
            x = 657, y = 509,
            width = 425,
            height = 80)


class FrontEnd(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.back_end=BackEnd()
        self.back_end.connectServer()
        self.title("Easy English App")
        self.geometry('1250x650')
        self.protocol("WM_DELETE_WINDOW",self.on_closing)
        self.resizable(width = False, height = False)
        container = Frame(self)
        container.pack(side = "top", fill = "both", expand = True)
        container.grid_rowconfigure(0, weight = 1)
        container.grid_columnconfigure(0, weight = 1)
        self.frames = {}
        for f in ( HomePage, EntryPage, Login):
            self.frames[str(f).split('.')[-1][:-2]] = f
        self.entryScreen()
    def on_closing(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            self.back_end.getRequest('','','Exit')
            self.back_end.sendRequest()
            self.destroy()

    def navigate(self, newFrame:Frame):
        container = Frame(self)
        container.pack(side = "top", fill = "both", expand = True)
        container.grid_rowconfigure(0, weight = 1)
        container.grid_columnconfigure(0, weight = 1)
        newFrame(self,container,self,self.back_end)
            
    def entryScreen(self):
        container = Frame(self)
        container.pack(side = "top", fill = "both", expand = True)
        container.grid_rowconfigure(0, weight = 1)
        container.grid_columnconfigure(0, weight = 1)
        EntryPage(self,container,self,self.back_end)