import os
import socket
import json

class BackEnd():
	def __init__(self):
		self.serverIP=socket.gethostbyname(socket.gethostname())
		self.port=12345
		self.format="utf8"
	def connectServer(self):
		self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.client.connect((self.serverIP, self.port))
	def getRequest(self,group,types,data):
		self.data_send={'group':group,'type':types,'data':data}
		self.message_request=json.dumps(self.data_send)
	def sendRequest(self):
		self.client.sendall(self.message_request.encode(self.format))
	def getResponse(self):
		self.message_response = dict(json.loads(self.client.recv(1024).decode(self.format)))
	def parseResponse(self):
		return {'type':self.data_send['type'],'data':self.message_response}
