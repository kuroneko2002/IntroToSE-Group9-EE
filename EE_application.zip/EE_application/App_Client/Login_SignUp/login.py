from tkinter import*
import socket
from tkinter import font
from tkinter import messagebox
import tkinter.scrolledtext as scrollText
import tkinter.ttk as exTk
from App_Client.backEnd import BackEnd
import json

def btn_clicked():
    print('clicked')
class Login(Frame):
    def __init__(self,window,master,frontEnd,backEnd):
        self.back_end=backEnd
        self.userName=""
        self.passWord=""
        Frame.__init__(self,master)
        self.canvas = Canvas(
            window,
            bg = "#FFFFFF",
            height = 780,
            width = 1500,
            bd = 0,
            highlightthickness = 0,
            relief = "ridge")
        
        # Background
        self.background_img = PhotoImage(file = f"./image/bg_login.png")

        # TextBox: Password
        self.entry_password_img = PhotoImage(file =f"./image/login_textbox_password.png")

        self.entry_password = Entry(
            font = ("cambria", 14),
            bd = 0,
            bg = "#FFFFFF",
            fg = "#535353",
            highlightthickness = 0)

        # TextBox: Username
        self.entry_username_img = PhotoImage(file = f"./image/login_textbox_username.png")

        self.entry_username = Entry(
            font = ("cambria", 14),
            bd = 0,
            bg = "#FFFFFF",
            fg = "#535353",
            highlightthickness = 0)

        # Button: Log In
        self.button_login_img = PhotoImage(file = f"./image/login_button_login.png")
        self.button_login = Button(
            activebackground = "#983493",
            bg = "#983493",
            image = self.button_login_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = lambda: self.login(frontEnd),
            relief = "flat")

        # Button: Back
        self.button_back_img = PhotoImage(file = f"./image/login_button_back.png")
        self.button_back = Button(
            activebackground = "#89399D",
            bg = "#89399D",
            image = self.button_back_img,
            borderwidth = 0,
            highlightthickness = 0,
            command = lambda: frontEnd.navigate(frontEnd.frames['EntryPage']),
            relief = "flat")
        self.homeScreen()


    def homeScreen(self):
        self.canvas.place(x = 0, y = 0)
        self.background = self.canvas.create_image(
            750.0, 390.0,
            image=self.background_img)
        self.entry_password_bg = self.canvas.create_image(
            750.0, 455.5,
            image = self.entry_password_img)
        self.entry_password.place(
            x = 554, y = 435,
            width = 392,
            height = 42)
        self.entry_username_bg = self.canvas.create_image(
            750.0, 368.5,
            image = self.entry_username_img)
        self.entry_username.place(
            x = 554, y = 348,
            width = 392,
            height = 42)
        self.button_login.place(
            x = 657, y = 518,
            width = 190,
            height = 59)
        self.button_back.place(
            x = 716, y = 633,
            width = 71,
            height = 71)

    def getUser(self):
        self.userName=self.entry_username.get()
        print(self.userName)
    def getPassword(self):
        self.passWord=self.entry_password.get()
    def login(self,frontEnd):
        self.getUser()
        self.getPassword()
        data={'user':self.userName,'password':self.passWord}
        self.back_end.getRequest('Login','Login',data)
        self.back_end.sendRequest()
        self.back_end.getResponse()
        result=self.back_end.parseResponse()
        if result['data']['data']==False:
            messagebox.showerror("Error", result['err_msg'])
            self.homeScreen()
        else:
            frontEnd.navigate(frontEnd.frames['HomePage'])