from tkinter import*
import socket
from tkinter import font
from tkinter import messagebox
import tkinter.scrolledtext as scrollText
import tkinter.ttk as exTk

class LogOut(Frame):
	pass
