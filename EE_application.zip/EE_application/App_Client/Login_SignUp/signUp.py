from tkinter import*
import socket
from tkinter import font
from tkinter import messagebox
import tkinter.scrolledtext as scrollText
import tkinter.ttk as exTk

def btn_clicked():
    print('clicked')
class RegisterPage(Frame):
	def __init__(self,window,master,frontEnd):
		Frame.__init__(self,master)
		self.canvas = Canvas(
			window,
			bg = "#FFFFFF",
			height = 780,
			width = 1500,
			bd = 0,
			highlightthickness = 0,
			relief = "ridge")
		self.canvas.place(x = 0, y = 0)


		# Background
		self.background_img = PhotoImage(file = f"./image/bg_signup.png")
		self.background = self.canvas.create_image(
			750.0, 379.0,
			image=self.background_img)


		# Textbox: Your full name
		self.entry_your_full_name_img = PhotoImage(file = f"./image/signup_textbox_info.png")
		self.entry_your_full_name_bg = self.canvas.create_image(
			508.0, 317.5,
			image = self.entry_your_full_name_img)

		self.entry_your_full_name = Entry(
			font = ("cambria", 14),
			bd = 0,
			bg = "#FFFFFF",
			fg = "#535353",
			highlightthickness = 0)

		self.entry_your_full_name.place(
			x = 313, y = 297,
			width = 390,
			height = 42)


		# Textbox: Date of birth
		self.entry_date_of_birth_img = PhotoImage(file = f"./image/signup_textbox_info.png")
		self.entry_date_of_birth_bg = self.canvas.create_image(
			508.0, 404.5,
			image = self.entry_date_of_birth_img)

		self.entry_date_of_birth = Entry(
			font = ("cambria", 14),
			bd = 0,
			bg = "#FFFFFF",
			fg = "#535353",
			highlightthickness = 0)

		self.entry_date_of_birth.place(
			x = 313, y = 384,
			width = 390,
			height = 42)


		# Textbox: Your email
		self.entry_your_email_img = PhotoImage(file = f"./image/signup_textbox_info.png")
		self.entry_your_email_bg = self.canvas.create_image(
			508.0, 490.5,
			image = self.entry_your_email_img)

		self.entry_your_email = Entry(
			font = ("cambria", 14),
			bd = 0,
			bg = "#FFFFFF",
			fg = "#535353",
			highlightthickness = 0)

		self.entry_your_email.place(
			x = 313, y = 470,
			width = 390,
			height = 42)


		# Textbox: Username
		self.entry_user_name_img = PhotoImage(file = f"./image/signup_textbox_info.png")
		self.entry_username_bg = self.canvas.create_image(
			992.0, 317.5,
			image = self.entry_user_name_img)

		self.entry_username = Entry(
			font = ("cambria", 14),
			bd = 0,
			bg = "#FFFFFF",
			fg = "#535353",
			highlightthickness = 0)

		self.entry_username.place(
			x = 797, y = 297,
			width = 390,
			height = 42)


		# Textbox: Password
		self.entry_password_img = PhotoImage(file = f"./image/signup_textbox_info.png")
		self.entry_password_bg = self.canvas.create_image(
			992.0, 404.5,
			image = self.entry_password_img)

		self.entry_password = Entry(
			font = ("cambria", 14),
			bd = 0,
			bg = "#FFFFFF",
			fg = "#535353",
			highlightthickness = 0)

		self.entry_password.place(
			x = 797, y = 384,
			width = 390,
			height = 42)


		# Textbox: Re_enter password
		self.entry_re_password_img = PhotoImage(file = f"./image/signup_textbox_info.png")
		self.entry_re_password_bg = self.canvas.create_image(
			992.0, 490.5,
			image = self.entry_re_password_img)

		self.entry_re_password = Entry(
			font = ("cambria", 14),
			bd = 0,
			bg = "#FFFFFF",
			fg = "#535353",
			highlightthickness = 0)

		self.entry_re_password.place(
			x = 797, y = 470,
			width = 390,
			height = 42)


		# Button: Sign Up
		self.button_signup_img = PhotoImage(file = f"./image/signup_button_signup.png")
		self.button_signup = Button(
			activebackground = "#2FDC81",
			bg = "#2FDC81",
			image = self.button_signup_img,
			borderwidth = 0,
			highlightthickness = 0,
			command = btn_clicked,
			relief = "flat")

		self.button_signup.place(
			x = 657, y = 562,
			width = 190,
			height = 71)


		# Button: Back
		self.button_back_img = PhotoImage(file = f"./image/signup_button_back.png")
		self.button_back = Button(
			activebackground = "#34E77E",
			bg = "#34E77E",
			image = self.button_back_img,
			borderwidth = 0,
			highlightthickness = 0,
			command = lambda: frontEnd.navigate(frontEnd.frames['EntryPage']),
			relief = "flat")

		self.button_back.place(
			x = 716, y = 673,
			width = 71,
			height = 71)