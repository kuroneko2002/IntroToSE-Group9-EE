from models.myModules import CRUD_db
import json

def login(user):
    try:
        data = CRUD_db.get("Account", "Account", "user", user['user'])
        if (data == "None"):
            return 'Invalid username'

        if (data['password'] != user['password']):
            return 'Invalid password'


        # check already login?
        if (data['status'] == "onl"):
            return 'Already login'


        # Login confirmed
        data = CRUD_db.update_db("Account", "Account", "name", user['user'], "status", 'onl')
        return 'Succeed'

    except:
        return 'Error'
def signUp(user):
    try:
        data = CRUD_db.get("Account", "Account", "name", user['user'])
        if (data == None):
            CRUD_db.insert_db("Account", "Account",user)
            return 'Succeed'

        return 'Invalid user'
    except:
        return 'Error'

def logout(user):
    try:
        # Logout confirmed
        data = CRUD_db.update_db("Account", "Account", "name", user['user'], "status", 'off')
        if (data == "Succeed"):
            return data

        return 'Error'
    except:
        return 'Error'