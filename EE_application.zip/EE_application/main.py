from tkinter import*
import socket
from tkinter import font
from tkinter import messagebox
import tkinter.scrolledtext as scrollText
import tkinter.ttk as exTk
from App_Client.frontEnd import FrontEnd
import os

win = FrontEnd()
win.mainloop()
