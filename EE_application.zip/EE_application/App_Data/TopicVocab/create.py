import os 
from pymongo import MongoClient
import re

#connect to cluster in MongoDB
password='group9'
connection_string=f'mongodb+srv://group9:{password}@cluster0.yorkz9p.mongodb.net/?retryWrites=true&w=majority'
client=MongoClient(connection_string)

#connect to TopicVocab Database, if it doesn't exits now then mongodb will create it
vocab_db=client["TopicVocab"]

# #read existing inputs from device
inputs=[]
input_path='./Exist'
files=os.listdir(input_path)
inputs=[input_path+'/'+file for file in files]

#getting topic to set collection's names
coll_names=[i.split('_')[1] for i in inputs]

#set titles
titles=['word','type','spelling','vietnamese','synonyms','example','audio']

#get audio file names and csv file name for of each units
audio_list=[]
csv_list=[]
for  i in inputs:
    audio_files=os.listdir(i)
    r=re.compile('\w+.csv')
    csv_object_idx=audio_files.index(list(filter(r.match,audio_files))[0])
    temp=audio_files[csv_object_idx]
    audio_files.pop(csv_object_idx)
    audio_files.append(temp)
    csv_file_name=audio_files[-1]
    audio_files=audio_files[0:-1]
    csv_list.append(csv_file_name)
    audio_list.append(audio_files)

#get data for documents
for i in range(len(csv_list)):
    documents=[]
    document={}
    audio,word,types,spelling,vietnamese,synonyms,example=[],[],[],[],[],[],[]
    contents=[]
    #handling with audio files
    for j in audio_list[i]:
        with open(inputs[i]+'/'+j,'rb') as af:
            audio.append(af.read())
    #handling with csv files
    with open(inputs[i]+'/'+csv_list[i],encoding='utf-8-sig') as csvf:
        data=csvf.readlines()[1:]
        for d in data:
            d.strip()
            d=d.split(',')
            word.append(d[0])
            types.append(d[1])
            spelling.append(d[2])
            vietnamese.append(d[3].split(';'))
            synonyms.append(d[4].split(';'))
            example.append(d[5])
        contents=[[word[k],types[k],spelling[k],vietnamese[k],synonyms[k],example[k],audio[k]] for k in range(len(word))]
        for cnt in contents:
            document={titles[k]:cnt[k] for k in range(len(cnt))}
            documents.append(document)
    #create collection corresponding with the current topic
    collection=vocab_db[coll_names[i]]
    collection.insert_many(documents)
