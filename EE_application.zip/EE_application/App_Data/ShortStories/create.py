import os 
import docx
from pymongo import MongoClient

#két nối đến database
password='group9'
connection_string=f'mongodb+srv://group9:{password}@cluster0.yorkz9p.mongodb.net/?retryWrites=true&w=majority'
client=MongoClient(connection_string)
stories_db=client["ShortStories"]
stories_coll=stories_db["ShortStories"]

inputs=[]
input_path='./Database/ShortStory'
files=os.listdir(input_path)
inputs=[input_path+'/'+file for file in files]

documents=[]
for input in inputs:
    temp=[]
    doc=docx.Document(input)
    for p in doc.paragraphs:
        temp.append(p.text)
    name=temp[0]
    content=""
    index=0
    for i in range(1,len(temp)):
        index+=1
        if temp[i]!='':
            content = content + temp[i] +"\n"
        else:
            break
    words=[temp[i] for i in range(index+1,len(temp)-1)]
    document={'name':name, 'content':content, 'words':words}
    documents.append(document)

stories_coll.insert_many(documents)