import os 
from pymongo import MongoClient

#connect to cluster in MongoDB
password='group9'
connection_string=f'mongodb+srv://group9:{password}@cluster0.yorkz9p.mongodb.net/?retryWrites=true&w=majority'
client=MongoClient(connection_string)

#connect to Account Database
account_db=client["Account"]

#connect to Account Collection in Account Database
account_coll=account_db["Account"]

#read existing inputs from device
inputs=[]
input_path='./Exist'
files=os.listdir(input_path)
inputs=[input_path+'/'+file for file in files]

#create data for database
documents=[]
for input in inputs:
    document={}
    keys, values=[], []
    with open(input) as f:
        data=f.readlines()
        for d in data:
            key, value=d.split(': ')
            document[key]=value.replace('\n', '')
    documents.append(document)

account_coll.insert_many(documents)